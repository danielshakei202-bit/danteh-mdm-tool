# Danteh MDM Tool — Starter Website

This ZIP is a static website plus a basic Windows diagnostic launcher.

## Upload to GitHub Pages
1. Extract the ZIP.
2. Create/open your repository (for example, `danteh-mdm-tool`).
3. Upload the extracted files so `index.html` is at the repository root.
4. In GitHub, open **Settings → Pages** and publish from the main branch and root folder.

## Windows diagnostic launcher
Open `windows-tool` and follow its README. Install Android SDK Platform Tools from the official Android developer site first.

## Scope and safety
This starter project detects ADB/Fastboot availability and provides troubleshooting. It does not bypass MDM, defeat security controls, or exploit bootloaders. Use official manufacturer unlocking procedures and only service devices you own or are authorized to manage.

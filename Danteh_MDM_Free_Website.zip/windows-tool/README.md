# Windows Device Diagnostics

1. Install Android SDK Platform Tools from:
   https://developer.android.com/tools/releases/platform-tools
2. Add the extracted platform-tools directory to your Windows PATH, or run this batch file from a terminal where `adb` and `fastboot` are available.
3. Connect an authorized Android device.
4. Run `run.bat`.

This only checks tool availability and lists detected devices. It does not unlock a bootloader or remove MDM. Follow the manufacturer's official process for any bootloader unlock.

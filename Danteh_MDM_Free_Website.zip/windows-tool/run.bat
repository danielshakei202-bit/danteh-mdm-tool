@echo off
title Danteh MDM Device Diagnostics
echo ==========================================
echo      Danteh MDM Device Diagnostics
echo ==========================================
echo.
echo This launcher checks whether ADB and Fastboot are installed.
echo Install Android SDK Platform Tools and add its folder to PATH.
echo.
where adb
if errorlevel 1 (
  echo ADB was not found. Install Android SDK Platform Tools first.
) else (
  echo.
  echo ADB devices:
  adb devices
)
echo.
where fastboot
if errorlevel 1 (
  echo Fastboot was not found. Install Android SDK Platform Tools first.
) else (
  echo.
  echo Fastboot devices:
  fastboot devices
)
echo.
pause
